# Language Translation Tool

A simple translation web app created for CodeAlpha Artificial Intelligence Task 1.

## Features

- Enter text to translate
- Choose source and target languages
- Translate using a server-side Google Translate endpoint
- Copy translated text
- Listen to the translation with text-to-speech
- Swap source and target languages
- Hindi support, including the native label `हिन्दी`
- Loading, error, retry, and empty states
- Responsive desktop and mobile interface

## Supported languages

English, Spanish, French, German, Italian, Portuguese, Japanese, Korean, Chinese, Arabic, and Hindi.

## Project structure

```text
artifacts/
  api-server/                 Express API server
  language-translation-tool/  React + Vite frontend
lib/
  api-spec/                   OpenAPI contract
  api-client-react/           Generated React API client
  api-zod/                    Generated Zod validation schemas
  db/                         Shared database package
docs/
  Language_Translation_Tool_Project_Documentation.md
  GITHUB_UPLOAD_GUIDE.md
```

## Run locally

This project uses pnpm.

```bash
pnpm install
pnpm --filter @workspace/api-server run dev
```

In a second terminal:

```bash
pnpm --filter @workspace/language-translation-tool run dev
```

The frontend calls the API through `/api/translate`.

## CodeAlpha Task 1 checklist

- [x] User interface for entering text
- [x] Source language selection
- [x] Target language selection
- [x] Translation API request
- [x] Translated response displayed clearly
- [x] Copy button
- [x] Text-to-speech feature

See `docs/Language_Translation_Tool_Project_Documentation.md` for the project explanation and `docs/GITHUB_UPLOAD_GUIDE.md` for GitHub instructions.