# Language Translation Tool — Project Documentation

## 1. Project overview

The Language Translation Tool is a web application created for CodeAlpha Artificial Intelligence Task 1. It lets a user enter text, choose a source language and a target language, send the text to a translation API, and view the translated result.

The project also includes optional usability features: copying the result and listening to it through the browser's text-to-speech support.

## 2. Task requirements completed

| Requirement | Implementation |
| --- | --- |
| Enter text | A large text input is available on the main workspace |
| Select source language | Source language dropdown |
| Select target language | Target language dropdown |
| Use a translation API | The Express API server sends the request to Google Translate's translation endpoint |
| Display translated text | The result appears in the translation output panel |
| Copy translated text | Copy button in the output panel |
| Text-to-speech | Listen button uses the browser Speech Synthesis API |

## 3. Supported languages

- English — English
- Spanish — Español
- French — Français
- German — Deutsch
- Italian — Italiano
- Portuguese — Português
- Japanese — 日本語
- Korean — 한국어
- Chinese — 中文
- Arabic — العربية
- Hindi — हिन्दी

## 4. How the application works

1. The user enters text in the source text area.
2. The user selects the source and target languages.
3. The frontend sends a `POST` request to `/api/translate`.
4. The Express API validates the request.
5. The server calls the translation provider.
6. The translated text is returned to the frontend.
7. The frontend displays the translation and enables copy and speech actions.

## 5. API contract

### Request

```http
POST /api/translate
Content-Type: application/json
```

```json
{
  "text": "Good morning, how are you?",
  "sourceLanguage": "en",
  "targetLanguage": "hi"
}
```

### Response

```json
{
  "translatedText": "सुप्रभात आप कैसे हैं?",
  "sourceLanguage": "en",
  "targetLanguage": "hi",
  "provider": "Google Translate"
}
```

## 6. Main technologies

- React
- Vite
- TypeScript
- Express
- OpenAPI
- Orval-generated React Query client
- Zod validation
- Tailwind CSS
- Lucide icons
- Browser Speech Synthesis API

## 7. Important source files

```text
artifacts/language-translation-tool/src/App.tsx
```

Contains the translation interface, language list, form state, loading state, result state, copy action, speech action, and language swap action.

```text
artifacts/api-server/src/routes/translation.ts
```

Validates translation requests and communicates with the translation provider.

```text
lib/api-spec/openapi.yaml
```

Defines the typed `/api/translate` API contract.

```text
artifacts/language-translation-tool/src/index.css
```

Contains the visual theme and responsive styling.

## 8. Notes for demonstration

The tool does not require an API key for the included translation endpoint. For a production application, the server adapter can be replaced with an official Google Cloud Translation or Microsoft Translator integration and its credentials can be stored as environment secrets.