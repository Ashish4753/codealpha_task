# Upload the Language Translation Tool to GitHub

## Recommended repository name

Use:

```text
CodeAlpha_Language_Translation_Tool
```

## Option 1: Upload through the GitHub website

1. Download and extract the provided source-code ZIP.
2. Sign in at [github.com](https://github.com).
3. Click **New repository**.
4. Enter the repository name:

   ```text
   CodeAlpha_Language_Translation_Tool
   ```

5. Choose **Public** if CodeAlpha requires a public repository.
6. Do not add another README or `.gitignore`; the project already includes both.
7. Click **Create repository**.
8. Open the new repository and click **Add file** → **Upload files**.
9. Open the extracted project folder and select the project files and folders:

   ```text
   artifacts
   docs
   lib
   scripts
   .gitignore
   README.md
   package.json
   pnpm-lock.yaml
   pnpm-workspace.yaml
   replit.md
   tsconfig.base.json
   tsconfig.json
   ```

10. Drag them into the GitHub upload area.
11. Scroll down, enter this commit message:

    ```text
    Add CodeAlpha language translation tool
    ```

12. Click **Commit changes**.

## Option 2: Upload using Git

Open a terminal inside the extracted project folder and run:

```bash
git init
git add .
git commit -m "Add CodeAlpha language translation tool"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/CodeAlpha_Language_Translation_Tool.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

If GitHub asks you to sign in, complete the browser sign-in or use GitHub Desktop. Do not put passwords, API keys, or other secrets into the project files.

## Check that the upload worked

Refresh the GitHub repository page. You should see:

- `artifacts/`
- `docs/`
- `lib/`
- `scripts/`
- `README.md`
- `package.json`
- `pnpm-lock.yaml`
- `pnpm-workspace.yaml`

Open `README.md` on GitHub to show the project description and the CodeAlpha Task 1 checklist.

## Suggested LinkedIn post

```text
Completed CodeAlpha AI Internship Task 1: Language Translation Tool.

The project lets users enter text, choose source and target languages, translate using an API, copy the result, and listen to the translation with text-to-speech.

GitHub: [paste your repository link here]

#CodeAlpha #ArtificialIntelligence #WebDevelopment #TypeScript #React
```