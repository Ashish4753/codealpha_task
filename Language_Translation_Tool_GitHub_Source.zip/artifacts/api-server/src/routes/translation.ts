import { Router, type IRouter } from "express";
import { TranslateTextBody, TranslateTextResponse } from "@workspace/api-zod";

const router: IRouter = Router();

type GoogleTranslateResponse = Array<
  Array<[string, string, ...unknown[]]> | string | null
>;

router.post("/translate", async (req, res) => {
  const parsed = TranslateTextBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Enter text and choose both languages." });
    return;
  }

  const { text, sourceLanguage, targetLanguage } = parsed.data;

  if (sourceLanguage === targetLanguage) {
    res.json(
      TranslateTextResponse.parse({
        translatedText: text,
        sourceLanguage,
        targetLanguage,
        provider: "same-language",
      }),
    );
    return;
  }

  const params = new URLSearchParams({
    client: "gtx",
    sl: sourceLanguage,
    tl: targetLanguage,
    dt: "t",
    q: text,
  });

  try {
    const response = await fetch(
      `https://translate.googleapis.com/translate_a/single?${params.toString()}`,
      {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(12_000),
      },
    );
    const payload = (await response.json()) as GoogleTranslateResponse;
    const translatedText = Array.isArray(payload?.[0])
      ? payload[0]
          .filter(
            (part): part is [string, string, ...unknown[]] =>
              Array.isArray(part) && typeof part[0] === "string",
          )
          .map((part) => part[0])
          .join("")
          .trim()
      : "";

    if (!response.ok || !translatedText) {
      req.log.warn(
        {
          httpStatus: response.status,
        },
        "Translation provider returned no translation",
      );
      res.status(502).json({
        error: "The translation provider could not translate this text.",
      });
      return;
    }

    res.json(
      TranslateTextResponse.parse({
        translatedText,
        sourceLanguage,
        targetLanguage,
        provider: "Google Translate",
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Translation provider request failed");
    res.status(502).json({
      error: "The translation service is temporarily unavailable.",
    });
  }
});

export default router;