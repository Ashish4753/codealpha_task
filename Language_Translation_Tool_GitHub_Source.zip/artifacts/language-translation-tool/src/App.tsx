import { useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDownUp,
  AudioLines,
  Check,
  ChevronDown,
  CircleAlert,
  Clipboard,
  Clock3,
  Globe2,
  Languages,
  Menu,
  RotateCcw,
  Send,
  Settings2,
  Sparkles,
  Volume2,
  X,
} from 'lucide-react';
import { useTranslateText } from '@workspace/api-client-react';
import type { TranslationInput, TranslationResult } from '@workspace/api-client-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

const LANGUAGES = [
  { code: 'en', name: 'English', native: 'English' },
  { code: 'es', name: 'Spanish', native: 'Español' },
  { code: 'fr', name: 'French', native: 'Français' },
  { code: 'de', name: 'German', native: 'Deutsch' },
  { code: 'it', name: 'Italian', native: 'Italiano' },
  { code: 'pt', name: 'Portuguese', native: 'Português' },
  { code: 'ja', name: 'Japanese', native: '日本語' },
  { code: 'ko', name: 'Korean', native: '한국어' },
  { code: 'zh', name: 'Chinese', native: '中文' },
  { code: 'ar', name: 'Arabic', native: 'العربية' },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
];

const STARTER_PHRASES = [
  { text: 'Where is the nearest train station?', from: 'English', to: 'Spanish' },
  { text: 'The meeting starts at nine tomorrow.', from: 'English', to: 'French' },
  { text: 'I would like a glass of sparkling water.', from: 'English', to: 'Italian' },
];

function languageName(code: string) {
  return LANGUAGES.find((language) => language.code === code)?.name ?? code;
}

function BrandMark() {
  return (
    <div className="flex items-center gap-3" data-testid="brand-language-translation-tool">
      <div className="relative flex size-9 items-center justify-center rounded-[11px] bg-primary text-primary-foreground shadow-[0_8px_20px_hsl(var(--primary)/.25)]">
        <Languages className="size-[18px]" strokeWidth={2.3} />
        <span className="absolute -right-1 -top-1 size-2 rounded-full bg-accent ring-2 ring-sidebar" />
      </div>
      <div>
        <p className="font-bold leading-4 tracking-[-0.03em] text-[13px]">Language Translation Tool</p>
        <p className="font-mono-ui text-[9px] uppercase tracking-[0.2em] text-sidebar-foreground/50">translation / 01</p>
      </div>
    </div>
  );
}

function LanguageSelect({
  label,
  value,
  onChange,
  testId,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  testId: string;
}) {
  return (
    <label className="group block" data-testid={`${testId}-field`}>
      <span className="mb-2 block font-mono-ui text-[10px] uppercase tracking-[0.17em] text-muted-foreground">{label}</span>
      <span className="relative block">
        <select
          className="h-12 w-full appearance-none rounded-xl border border-input bg-background/70 px-4 pr-10 text-sm font-semibold text-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/15"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          data-testid={testId}
          aria-label={label}
        >
          {LANGUAGES.map((language) => (
            <option value={language.code} key={language.code}>
              {language.name} · {language.native}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground transition-transform group-focus-within:rotate-180" />
      </span>
    </label>
  );
}

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <>
      {open && <button className="fixed inset-0 z-30 bg-foreground/25 md:hidden" onClick={onClose} aria-label="Close menu" data-testid="button-close-menu" />}
      <aside className={`lingua-sidebar fixed inset-y-0 left-0 z-40 flex w-[278px] flex-col border-r border-sidebar-border px-5 py-6 transition-transform duration-300 md:relative md:z-0 md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between">
          <BrandMark />
          <button className="rounded-lg p-2 text-sidebar-foreground/55 hover:bg-sidebar-accent hover:text-sidebar-foreground md:hidden" onClick={onClose} aria-label="Close navigation" data-testid="button-close-navigation">
            <X className="size-4" />
          </button>
        </div>

        <div className="mt-12">
          <p className="px-3 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-sidebar-foreground/40">Workspace</p>
          <nav className="mt-3 space-y-1" aria-label="Main navigation">
            <button className="flex w-full items-center gap-3 rounded-xl bg-sidebar-accent px-3 py-3 text-left text-sm font-semibold text-sidebar-foreground" data-testid="button-nav-translator">
              <Globe2 className="size-[17px] text-sidebar-primary" />
              Translator
              <span className="ml-auto font-mono-ui text-[10px] text-sidebar-foreground/40">⌘ 1</span>
            </button>
            <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground" onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })} data-testid="button-nav-recent">
              <Clock3 className="size-[17px]" />
              Recent phrases
            </button>
          </nav>
        </div>

        <div className="mt-auto">
          <div className="rounded-2xl border border-sidebar-border bg-sidebar-accent/55 p-4">
            <div className="flex items-center justify-between">
              <span className="font-mono-ui text-[10px] uppercase tracking-[0.16em] text-sidebar-foreground/45">Language pair</span>
              <Settings2 className="size-3.5 text-sidebar-foreground/45" />
            </div>
            <div className="mt-4 flex items-center gap-2">
              <span className="rounded-md bg-sidebar-primary/15 px-2 py-1 font-mono-ui text-[11px] text-sidebar-primary">EN</span>
              <ArrowDownUp className="size-3.5 text-sidebar-foreground/40" />
              <span className="rounded-md bg-accent/15 px-2 py-1 font-mono-ui text-[11px] text-accent">ES</span>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-sidebar-foreground/55">Switch languages from the workspace when you are ready.</p>
          </div>
          <div className="mt-6 flex items-center justify-between px-1 text-[11px] text-sidebar-foreground/35">
            <span>Private by default</span>
            <span className="font-mono-ui">v1.0</span>
          </div>
        </div>
      </aside>
    </>
  );
}

function ResultPane({
  result,
  isPending,
  error,
  onRetry,
}: {
  result: TranslationResult | null;
  isPending: boolean;
  error: boolean;
  onRetry: () => void;
}) {
  const [copied, setCopied] = useState(false);

  const copyResult = async () => {
    if (!result?.translatedText) return;
    try {
      await navigator.clipboard.writeText(result.translatedText);
    } catch {
      const helper = document.createElement('textarea');
      helper.value = result.translatedText;
      document.body.appendChild(helper);
      helper.select();
      document.execCommand('copy');
      helper.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const speakResult = () => {
    if (!result?.translatedText || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(result.translatedText);
    utterance.lang = result.targetLanguage;
    window.speechSynthesis.speak(utterance);
  };

  return (
    <section className="lingua-card flex min-h-[348px] flex-col overflow-hidden rounded-[22px]" data-testid="panel-translation-result">
      <div className="flex items-center justify-between border-b border-border/75 px-5 py-4 sm:px-6">
        <div className="flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-lg bg-accent/15 text-accent"><Sparkles className="size-3.5" /></div>
          <div>
            <p className="text-sm font-bold">Translation</p>
            <p className="font-mono-ui text-[9px] uppercase tracking-[0.16em] text-muted-foreground">Output</p>
          </div>
        </div>
        {result && !isPending && (
          <div className="flex items-center gap-1">
            <button className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" onClick={copyResult} title="Copy translation" aria-label="Copy translation" data-testid="button-copy-translation">
              {copied ? <Check className="size-4 text-primary" /> : <Clipboard className="size-4" />}
            </button>
            <button className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" onClick={speakResult} title="Listen to translation" aria-label="Listen to translation" data-testid="button-speak-translation">
              <Volume2 className="size-4" />
            </button>
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5 sm:p-6">
        {isPending && (
          <div className="space-y-4" aria-label="Translating" data-testid="status-translating">
            <div className="lingua-pulse h-4 w-3/4 rounded-full bg-muted" />
            <div className="lingua-pulse h-4 w-full rounded-full bg-muted" />
            <div className="lingua-pulse h-4 w-1/2 rounded-full bg-muted" />
            <div className="mt-8 flex items-center gap-2 text-xs text-muted-foreground"><span className="size-1.5 rounded-full bg-primary" />Finding the right words…</div>
          </div>
        )}
        {!isPending && error && (
          <div className="flex flex-1 flex-col items-center justify-center text-center" data-testid="status-translation-error">
            <div className="flex size-11 items-center justify-center rounded-full bg-destructive/10 text-destructive"><CircleAlert className="size-5" /></div>
            <h3 className="mt-4 text-sm font-bold">We could not translate that</h3>
            <p className="mt-1 max-w-[250px] text-xs leading-relaxed text-muted-foreground">The translation service is taking a quiet moment. Try sending it again.</p>
            <button className="mt-5 inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-xs font-semibold transition-colors hover:bg-muted" onClick={onRetry} data-testid="button-retry-translation">
              <RotateCcw className="size-3.5" /> Try again
            </button>
          </div>
        )}
        {!isPending && !error && result && (
          <div className="lingua-in flex flex-1 flex-col" data-testid="text-translated-result">
            <p className="max-w-[620px] whitespace-pre-wrap text-[21px] font-semibold leading-[1.45] tracking-[-0.025em] text-foreground sm:text-[25px]">{result.translatedText}</p>
            <div className="mt-auto flex items-center gap-2 pt-8 font-mono-ui text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
              <span>{languageName(result.targetLanguage)}</span>
              <span className="size-1 rounded-full bg-primary" />
              <span>{result.provider || 'Translation engine'}</span>
            </div>
          </div>
        )}
        {!isPending && !error && !result && (
          <div className="flex flex-1 flex-col items-center justify-center text-center" data-testid="status-empty-result">
            <div className="relative flex size-[74px] items-center justify-center rounded-[22px] border border-dashed border-primary/35 bg-primary/5 text-primary">
              <AudioLines className="size-7" strokeWidth={1.5} />
              <span className="absolute -right-1 -top-1 size-2.5 rounded-full bg-accent" />
            </div>
            <h3 className="mt-5 text-sm font-bold">Your words, on the other side</h3>
            <p className="mt-1 max-w-[230px] text-xs leading-relaxed text-muted-foreground">Your translation will land here, ready to copy or hear out loud.</p>
          </div>
        )}
      </div>
    </section>
  );
}

function Home() {
  const [sourceLanguage, setSourceLanguage] = useState('en');
  const [targetLanguage, setTargetLanguage] = useState('es');
  const [text, setText] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [result, setResult] = useState<TranslationResult | null>(null);
  const lastRequest = useRef<TranslationInput | null>(null);
  const translate = useTranslateText();

  const submitTranslation = (payload: TranslationInput = { text, sourceLanguage, targetLanguage }) => {
    if (!payload.text.trim() || translate.isPending) return;
    lastRequest.current = payload;
    setResult(null);
    translate.mutate({ data: payload }, {
      onSuccess: (translation) => setResult(translation),
    });
  };

  const swapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setResult(null);
  };

  const useStarter = (phrase: (typeof STARTER_PHRASES)[number]) => {
    const source = LANGUAGES.find((language) => language.name === phrase.from)?.code ?? 'en';
    const target = LANGUAGES.find((language) => language.name === phrase.to)?.code ?? 'es';
    setSourceLanguage(source);
    setTargetLanguage(target);
    setText(phrase.text);
    setResult(null);
  };

  return (
    <div className="lingua-shell flex min-h-[100dvh] w-full">
      <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <main className="lingua-grid min-w-0 flex-1">
        <header className="mx-auto flex max-w-[1220px] items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
          <button className="rounded-xl border border-border bg-card/70 p-2.5 text-muted-foreground md:hidden" onClick={() => setMenuOpen(true)} aria-label="Open navigation" data-testid="button-open-navigation">
            <Menu className="size-4" />
          </button>
          <div className="hidden items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[0.16em] text-muted-foreground md:flex" data-testid="status-workspace">
            <span className="size-1.5 rounded-full bg-primary" /> Workspace ready
          </div>
          <div className="ml-auto flex items-center gap-3">
            <span className="hidden text-xs text-muted-foreground sm:inline">A calmer way to say it.</span>
            <div className="flex size-8 items-center justify-center rounded-full bg-foreground text-[11px] font-bold text-background" data-testid="avatar-user">LM</div>
          </div>
        </header>

        <div className="mx-auto max-w-[1220px] px-5 pb-12 sm:px-8 lg:px-12">
          <section className="lingua-in pb-10 pt-8 sm:pb-12 sm:pt-14">
            <p className="font-mono-ui text-[10px] uppercase tracking-[0.22em] text-primary" data-testid="text-eyebrow">Language workspace / 01</p>
            <div className="mt-5 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
              <div className="max-w-[670px]">
                <h1 className="text-balance text-[clamp(2.3rem,5vw,4.5rem)] font-extrabold leading-[.98] tracking-[-0.065em] text-foreground">Say what you mean.<br /><span className="text-primary">In any language.</span></h1>
                <p className="mt-5 max-w-[500px] text-sm leading-7 text-muted-foreground sm:text-[15px]">A focused place to move ideas between languages — with the nuance, rhythm, and confidence they deserve.</p>
              </div>
              <div className="hidden max-w-[185px] border-l border-primary/35 pl-4 text-xs leading-5 text-muted-foreground lg:block">
                <span className="mb-2 block font-mono-ui text-[10px] uppercase tracking-[0.14em] text-foreground">Built for the in-between</span>
                For the message you need to send, the sign you need to read, and the thought that should not get lost.
              </div>
            </div>
          </section>

          <section className="lingua-card lingua-in-delay overflow-hidden rounded-[22px]" data-testid="translation-workspace">
            <div className="grid lg:grid-cols-[1fr_1fr]">
              <div className="border-b border-border/75 p-5 sm:p-7 lg:border-b-0 lg:border-r">
                <div className="flex items-end justify-between gap-4">
                  <LanguageSelect label="I’m writing in" value={sourceLanguage} onChange={(value) => { setSourceLanguage(value); setResult(null); }} testId="select-source-language" />
                  <button className="mb-0.5 flex size-10 shrink-0 items-center justify-center rounded-xl border border-border bg-background/65 text-muted-foreground transition-all hover:border-primary/40 hover:text-primary active:scale-95" onClick={swapLanguages} title="Swap languages" aria-label="Swap source and target languages" data-testid="button-swap-languages">
                    <ArrowDownUp className="size-4" />
                  </button>
                </div>
                <div className="relative mt-6">
                  <textarea
                    className="min-h-[190px] w-full resize-none bg-transparent text-[18px] leading-8 tracking-[-0.02em] text-foreground outline-none placeholder:text-muted-foreground/55 sm:min-h-[215px] sm:text-[21px]"
                    placeholder="Start with a thought, a question, or a phrase…"
                    value={text}
                    maxLength={5000}
                    onChange={(event) => { setText(event.target.value); setResult(null); }}
                    data-testid="input-source-text"
                    aria-label="Text to translate"
                  />
                  <div className="mt-3 flex items-center justify-between border-t border-border/65 pt-3">
                    <span className="font-mono-ui text-[10px] text-muted-foreground" data-testid="text-character-count">{text.length.toLocaleString()} / 5,000</span>
                    {text && <button className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground hover:text-foreground" onClick={() => { setText(''); setResult(null); }} data-testid="button-clear-text"><X className="size-3.5" /> Clear</button>}
                  </div>
                </div>
              </div>

              <div className="flex flex-col p-5 sm:p-7">
                <LanguageSelect label="Translate to" value={targetLanguage} onChange={(value) => { setTargetLanguage(value); setResult(null); }} testId="select-target-language" />
                <div className="mt-6 flex flex-1 flex-col">
                  <ResultPane result={result} isPending={translate.isPending} error={translate.isError} onRetry={() => lastRequest.current && submitTranslation(lastRequest.current)} />
                </div>
              </div>
            </div>
            <div className="flex flex-col items-start justify-between gap-4 border-t border-border/75 bg-muted/35 px-5 py-4 sm:flex-row sm:items-center sm:px-7">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex size-5 items-center justify-center rounded-full bg-primary/10 text-primary"><Sparkles className="size-3" /></span>
                <span>Clear context in. Natural language out.</span>
              </div>
              <button className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-[0_8px_20px_hsl(var(--primary)/.2)] transition-all hover:-translate-y-0.5 hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:translate-y-0 sm:w-auto" onClick={() => submitTranslation()} disabled={!text.trim() || translate.isPending} data-testid="button-translate">
                {translate.isPending ? <span className="size-4 animate-pulse rounded-full border-2 border-primary-foreground/35 border-t-primary-foreground" /> : <Send className="size-4" />}
                {translate.isPending ? 'Translating' : 'Translate'}
              </button>
            </div>
          </section>

          <section className="lingua-in-delay-2 mt-10" data-testid="section-starter-phrases">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-mono-ui text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Need a starting point?</p>
                <h2 className="mt-1 text-sm font-bold">Try a phrase</h2>
              </div>
              <span className="hidden text-xs text-muted-foreground sm:block">Tap to bring it into your workspace</span>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-3">
              {STARTER_PHRASES.map((phrase, index) => (
                <button key={phrase.text} className="group rounded-2xl border border-border bg-card/55 p-4 text-left transition-all hover:-translate-y-0.5 hover:border-primary/35 hover:bg-card" onClick={() => useStarter(phrase)} data-testid={`button-starter-phrase-${index}`}>
                  <p className="text-sm font-semibold leading-6 text-foreground/85">“{phrase.text}”</p>
                  <div className="mt-4 flex items-center gap-2 font-mono-ui text-[9px] uppercase tracking-[0.13em] text-muted-foreground">
                    <span>{phrase.from.slice(0, 2)}</span><ArrowDownUp className="size-3 text-primary transition-transform group-hover:translate-x-0.5" /><span>{phrase.to.slice(0, 2)}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>

          <footer className="mt-16 flex flex-col gap-3 border-t border-border/70 pt-5 text-[11px] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
            <span>Language Translation Tool is a companion for understanding, not a replacement for it.</span>
            <span className="font-mono-ui uppercase tracking-[0.14em]">Translate with care</span>
          </footer>
        </div>
      </main>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
